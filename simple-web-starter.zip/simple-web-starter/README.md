# Simple Web Starter (HTML + CSS)

This is a tiny starter project you can open in **VS Code (web)** and preview in a browser.

## What’s inside
- `index.html` (the page)
- `styles.css` (the styling)

## How to use (student steps)
1) **Download** this zip and **extract** it.
2) Open the extracted folder in **VS Code (web)**.
3) Open `index.html` and `styles.css`.
4) To preview (no Live Preview needed):
   - Find `index.html` in your file explorer (outside VS Code)
   - Double-click it, or right-click → **Open with** → your browser
   - After edits, **save** and **refresh** the browser tab (Ctrl/Cmd + R)

## Quick Exercise (10–12 minutes)
Make these changes, saving after each one and refreshing the browser:

### Part A — HTML edits (3–4 min)
- Replace `YOUR NAME` with your name.
- Change the page title in the browser tab (the `<title>` tag).
- Add ONE more item to the Favorites list.

### Part B — CSS edits (4–5 min)
- In `:root`, change `--accent` to a new color (try: `#0ea5e9`, `#16a34a`, or any hex).
- Make the cards a little rounder by changing `.card` `border-radius`.
- Change the `.btn` background color (`--accent-2`) or directly in `.btn`.

### Part C — Mini challenge (2–3 min)
Add a new section in HTML called **“Goals This Semester”** with 3 bullet points.
Then style it so it looks like the other cards (hint: reuse `class="card"`).

## Turn-in (simple)
Take a screenshot of your page after your changes and submit it.
